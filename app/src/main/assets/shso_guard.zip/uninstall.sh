#!/system/bin/sh
###############################################################################
# uninstall.sh — 模块被移除时执行
#
# 注意：执行时模块文件可能已被部分删除，所有操作都要先判存在。
# 不要依赖 $0 定位模块目录（不可靠），改用显式路径。
#
# 策略：保留审计日志与策略配置（取证价值 > 清理价值），
#       需要彻底清除时用户手动删除 /data/adb/shso_guard 即可。
###############################################################################

MODDIR=${0%/*}
[ ! -d "$MODDIR" ] && MODDIR="/data/adb/modules/shso_guard"

echo "[shso_guard] 卸载：保留 /data/adb/shso/audit.log（审计留痕）"
echo "[shso_guard] 卸载：保留 /data/adb/shso_guard/policy.conf（重装可复用配置）"

# 清理模块自建的临时产物（当前无）
# rm -f /data/adb/shso/audit.log.tmp

exit 0
