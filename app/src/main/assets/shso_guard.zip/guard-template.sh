#!/system/bin/sh
###############################################################################
# shso_guard 守卫：__CMD_NAME__
#
# 由 guard-template.sh 生成（占位符 __CMD_NAME__ / __OPERAND_MODE__ 已被替换）。
# 安装方式无关：既支持刷 zip（customize.sh），也支持直接把目录拷进
# /data/adb/modules/shso_guard（App 复制安装）——因此本文件必须开箱即用，
# 不依赖任何安装期生成的产物。
#
# 拦截流程：
#   取操作数 → 归一化 → 对照策略 → ALLOW/DENY → 审计 → 放行时 exec 真实二进制
# 关键：
#   - 真实二进制由 find_real() 在运行时按 PATH 查找并跳过 guard 目录（防递归），
#     因此不硬编码任何路径，也不依赖 busybox 位置。
#   - common.sh 缺失时拒绝执行（fail-closed），绝不静默放行。
###############################################################################

GUARD_SELF="$0"
GUARD_DIR="${GUARD_SELF%/*}"
CMD_NAME="__CMD_NAME__"
OPERAND_MODE="__OPERAND_MODE__"

# fail-closed：缺少公共库时直接拒绝，而不是退化成放行
if [ ! -f "$GUARD_DIR/common.sh" ]; then
    echo "shso_guard: common.sh 缺失，拒绝执行 ${CMD_NAME}（fail-closed）" >&2
    exit 1
fi

# shellcheck source=./common.sh
. "$GUARD_DIR/common.sh"
load_policy

# mode=off：完全放行（仅用于排障，不建议长期开启）
if [ "$SHSO_MODE" = "off" ]; then
    exec "$(find_real "$CMD_NAME")" "$@"
fi

#------------------------------------------------------------------------------
# 提取待判定的路径操作数
#   ARGS     —— 非 - 开头的参数视为路径（rm / rmdir / shred / mkfs.* …）
#   DD       —— 额外解析 of=<path>（真正造成破坏的是输出目标）
#   FASTBOOT —— 子命令判定（erase / format / wipe / flash 一律高危）
#------------------------------------------------------------------------------
_paths=""
case "$OPERAND_MODE" in
    DD)
        for _a in "$@"; do
            case "$_a" in
                of=*) _paths="$_paths ${_a#of=}" ;;
            esac
        done
        ;;
    FASTBOOT)
        for _a in "$@"; do
            case "$_a" in
                erase|format|wipe|flash|"oem unlock")
                    _paths="$_paths __FASTBOOT_DESTRUCTIVE__" ;;
            esac
        done
        ;;
    *)
        for _a in "$@"; do
            case "$_a" in
                --) continue ;;
                -*) ;;
                *)  _paths="$_paths $_a" ;;
            esac
        done
        ;;
esac

#------------------------------------------------------------------------------
# 判定
#------------------------------------------------------------------------------
_verdict="ALLOW"
_rule="NONE"
_hit=""

for _p in $_paths; do
    if [ "$_p" = "__FASTBOOT_DESTRUCTIVE__" ]; then
        _verdict="DENY"; _rule="FASTBOOT_DESTRUCTIVE"; _hit="fastboot $*"
        break
    fi
    _np=$(normalize_path "$_p")
    [ -z "$_np" ] && continue
    if [ "$(judge "$_np")" = "DENY" ]; then
        _verdict="DENY"; _rule="PROTECTED_PATH"; _hit="$_np"
        break
    fi
done

if [ "$_verdict" = "DENY" ]; then
    audit DENY "$_rule" "$CMD_NAME" "$*" "$_hit"
    # mode=log 只记录不拦截
    if [ "$SHSO_MODE" = "enforce" ]; then
        echo "shso_guard: 已拦截 [${CMD_NAME}] —— 命中受保护路径/危险操作: ${_hit}" >&2
        echo "shso_guard: 确需执行，请在 ${POLICY_FILE} 增加 allow= 或将 mode 改为 log" >&2
        exit 1
    fi
else
    audit ALLOW "$_rule" "$CMD_NAME" "$*" "${_paths:-}"
fi

exec "$(find_real "$CMD_NAME")" "$@"
