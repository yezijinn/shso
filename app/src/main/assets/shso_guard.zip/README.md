# shso_guard —— shso 指令守卫

shso 的配套 root 模块。**运行时**拦截 `rm` / `dd` / `mkfs` 等高危命令，
保护系统分区，并把每一次调用落进审计日志。

## 它解决什么问题

shso App 侧的指令审查（`ScriptAuditor`）是**静态文本分析**：读脚本内容找危险模式。
这在原理上可被绕过：

```sh
python  -c 'import shutil; shutil.rmtree("/system")'   # 不含 rm 关键字
echo Ym0gLXJmIC8= | base64 -d | sh                     # 解码后才出现 rm -rf /
eval "$(printf '\162\155') -rf /"                      # 八进制转义
```

本模块换了一层：**不分析文本，而是在命令真正被调用的那一刻拦下来**。
无论脚本用 `python -c`、`eval`、`base64 | sh` 还是嵌套 `$()` 触发，
只要它最终去调用 `rm`，就会先经过守卫。

| 层 | 位置 | 能力 | 可绕过方式 |
|---|---|---|---|
| L1 静态审查 | App（Kotlin） | 弹确认框、展示风险行号 | 混淆 / 等价改写 |
| **L2 运行时守卫** | **本模块** | **任何调用路径都拦** | 直接写绝对路径 `/system/bin/rm`；或自行改 PATH |
| L3 审计留痕 | 两侧共用同一日志 | 事后追溯 | 有 root 即可篡改日志 |

## 安装

模块 ID：`shso_guard`（一经发布永不修改）。

### 方式 A：复制安装（shso App 集成推荐）

**安装模块 == 把文件放进 `/data/adb/modules/`**，不需要刷机、不需要重启：

```sh
cp -R  shso_guard  /data/adb/modules/shso_guard
chmod -R 0755      /data/adb/modules/shso_guard
chmod    0644      /data/adb/modules/shso_guard/module.prop
```

> **注意**：这种方式 `customize.sh` **不会执行**。因此本模块被设计成开箱即用：
> - `guard/` 下的守卫是**预生成**的，不依赖安装期逻辑；
> - 真实二进制路径由守卫在**运行时**按 PATH 查找（`find_real()`），
>   既不硬编码路径，也不依赖 busybox 位置；
> - `policy.conf` 随模块自带，`service.sh` 开机时兜底部署到 `/data/adb/shso_guard/`。

**守卫装完立刻生效**（拦截靠 PATH，不靠开机脚本）。
重启只是为了让模块在 Magisk / KSU / APatch 管理器里可见、并让 `service.sh` 跑一遍善后。

### 方式 B：刷 zip

```bash
python scripts/build.py . -o ../shso_guard.zip
```

Magisk App / KernelSU / APatch 均可直接刷入。Recovery 仅 Magisk 支持。

## 生效原理

守卫脚本与真实命令**同名**，放在 `guard/` 目录；把该目录前置到 `PATH` 后，
`rm` 会先命中守卫，守卫判定放行时再 `exec` 真实二进制：

```text
脚本里写 rm -rf /system
        │
        ▼  PATH 查找：/data/adb/modules/shso_guard/guard/rm
   ┌─────────────────┐
   │ 提取操作数 /system │
   │ 归一化（realpath） │   ← 防 /system/../data、符号链接绕过
   │ 对照 policy.conf  │   ← allow 优先于 protect
   │ 审计落盘          │   ← 先留痕，后动作
   └────────┬────────┘
       DENY │        │ ALLOW
            ▼        ▼
       exit 1    exec /system/bin/rm …
```

关键实现细节：
- **防递归**：`find_real()` 遍历 PATH 时跳过 guard 目录，永远 exec 真实二进制。
- **fail-closed**：`common.sh` 缺失时守卫**拒绝执行**并退出非 0，绝不静默放行。
- **根路径特殊处理**：`protect=/` 只做精确匹配（只拦 `rm -rf /`），
  否则 `/` + `/*` 的模式会误伤所有绝对路径。
- **`dd` 看 `of=`**：真正造成破坏的是输出目标，不是输入。
- **`fastboot` 看子命令**：`erase` / `format` / `wipe` / `flash` + `oem unlock` 一律高危。

## shso App 集成点

App 侧只需把守卫目录前置到 PATH（**目前尚未改动，待确认**）：

1. **脚本执行** —— `RootService.executeFile()`（`RootService.kt:239`）构造命令处，
   在 `export PATH=...` 最前面插入守卫目录：

```kotlin
val guardDir = "/data/adb/modules/shso_guard/guard"
val guardPath = if (File("$guardDir/rm").exists()) "$guardDir:" else ""
val execCmd = "export PATH=$guardPath/sbin:/system/sbin:/system/bin:/system/xbin:\$PATH && ..."
```

2. **终端输入** —— 常驻 root shell 启动时同样前置该目录，
   使 `sendInput()` 送进去的命令也经过守卫。

守卫未安装时 `guardPath` 为空串，行为与现在完全一致（优雅降级）。

## 策略配置

文件：`/data/adb/shso_guard/policy.conf`（修改后即时生效，无需重启）

```conf
mode=enforce        # enforce=拦截并记录 | log=只记录 | off=放行（排障用）
protect=/system     # 受保护路径，命中即拦
allow=/sdcard       # 豁免路径，优先级高于 protect
```

内置默认值见 `policy.conf`。判定顺序：**allow → protect**，
因此 `/data/media` 可以豁免 `/data` 的保护。

守卫找不到策略文件时会退回内置兜底清单，保证「裸装也受保护」。

## 审计日志

文件：`/data/adb/shso/audit.log`（与 App 侧共用，统一视图）

```text
2026-09-05 23:41:07|GUARD|DENY|PROTECTED_PATH|cmd=rm|args=-rf /system|path=/system
2026-09-05 23:41:09|GUARD|ALLOW|NONE|cmd=rm|args=-f /sdcard/a.log|path=/sdcard/a.log
```

超过 2400 行时自动保留尾部 2000 行（开机轮转 + 写入时兜底）。

## 能力边界（务必了解）

本模块**不是**安全沙箱，以下情况拦不住：

1. **直接调用绝对路径**：`/system/bin/rm -rf /system` 绕过了 PATH，守卫不会介入。
2. **自行改写 PATH**：脚本里 `export PATH=/system/bin:$PATH` 即可摘掉守卫。
3. **不走外部命令的实现**：`python -c 'shutil.rmtree(...)'` 直接做系统调用，
   根本不 fork `rm`——此时只能靠 L1 静态审查或「默认不给 Root」。
4. **有 root 就能改配置/日志**：拦不住一个决意的用户。

所以定位很清楚：**拦误操作 + 高危留痕 + 提高恶意脚本的门槛**，
真正的主防线仍是「脚本默认不以 Root 执行」。

## 通用性

| Root 方案 | 支持 | 说明 |
|---|---|---|
| Magisk | 原生支持 | — |
| KernelSU | 原生支持 | 本模块**不使用 `system/`**，无需 metamodule |
| APatch | 原生支持 | — |

模块为**纯脚本档位**（B 档）：仅 `module.prop` + `customize.sh` + `service.sh` +
`uninstall.sh` + `guard/`，零 `system/` 依赖，三种方案行为一致。
