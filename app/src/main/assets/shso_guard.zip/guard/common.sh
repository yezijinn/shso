#!/system/bin/sh
###############################################################################
# shso_guard 公共库 —— 策略判定 / 路径归一化 / 审计落盘
#
# 由 guard/<cmd> 脚本 source 调用，不可单独执行。
# 兼容性：仅用 POSIX sh 语法（Android mksh / ash 均可），不依赖 bash。
#
# 设计要点
#   1. 策略文件缺失时，使用内置兜底清单，保证「裸装也受保护」。
#   2. allow 先于 protect 判定，因此 /data/media 可以豁免 /data 的保护。
#   3. 路径判定前必须归一化，否则 /system/../data 可绕过。
#   4. 匹配 protect="/" 时只判精确相等，否则 `/*` 会误伤全部路径。
###############################################################################

# 守卫脚本 source 本文件前会显式设置 GUARD_DIR；此处仅为兜底推导，
# 不硬编码模块路径（复制安装时模块目录与 ID 绑定，写死会失效）。
# 被 source 时 $0 即调用方（guard/<cmd>）的路径，取其目录即 guard 目录。
GUARD_DIR="${GUARD_DIR:-${MODDIR:-${0%/*}}}"
POLICY_FILE="${SHSO_POLICY:-/data/adb/shso_guard/policy.conf}"
AUDIT_LOG="${SHSO_AUDIT:-/data/adb/shso/audit.log}"
AUDIT_MAX_LINES="${SHSO_AUDIT_MAX:-2000}"

# 内置兜底：受保护路径（策略文件缺失时生效）
DEFAULT_PROTECT="/ /system /system_ext /product /vendor /odm /apex /proc /sys /dev /data/system /data/misc /metadata"
# 内置兜底：豁免路径（优先级高于 protect）
DEFAULT_ALLOW="/sdcard /storage/emulated /data/media /data/adb/shso /data/local/tmp"

_POLICY_PROTECT=""
_POLICY_ALLOW=""
SHSO_MODE="enforce"

#------------------------------------------------------------------------------
# 工具函数
#------------------------------------------------------------------------------

# 去掉结尾斜杠（保留根 "/"）
strip_slash() {
    case "$1" in
        "/") echo "/" ;;
        */)  echo "${1%/}" ;;
        *)   echo "$1" ;;
    esac
}

# 路径归一化：优先 realpath（解析符号链接）；失败则词法处理 . 与 ..
# 说明：不改动调用者的位置参数（$@），内部只用局部变量。
normalize_path() {
    _p="$1"
    [ -z "$_p" ] && { echo ""; return 1; }

    if command -v realpath >/dev/null 2>&1; then
        _rp=$(realpath "$_p" 2>/dev/null)
        if [ -n "$_rp" ]; then
            strip_slash "$_rp"
            return 0
        fi
    fi

    case "$_p" in
        /*) _abs="$_p" ;;
        *)  _abs="$PWD/$_p" ;;
    esac

    _out=""
    _OIFS="$IFS"
    IFS='/'
    for _seg in $_abs; do
        case "$_seg" in
            ""|".") ;;
            "..") _out="${_out%/*}" ;;
            *)    _out="$_out/$_seg" ;;
        esac
    done
    IFS="$_OIFS"

    [ -z "$_out" ] && _out="/"
    strip_slash "$_out"
}

# 加载策略文件；三处都找不到则用内置兜底清单（绝不因此放行）
#
# 查找顺序（必须覆盖「复制安装」场景——该场景 customize.sh 不会执行）：
#   1) $SHSO_POLICY        —— 环境变量覆盖，便于临时排障
#   2) /data/adb/shso_guard/policy.conf —— 用户可编辑，重装模块不丢失
#   3) $GUARD_DIR/../policy.conf        —— 模块自带默认配置（复制安装即开箱可用）
load_policy() {
    _POLICY_PROTECT="$DEFAULT_PROTECT"
    _POLICY_ALLOW="$DEFAULT_ALLOW"
    SHSO_MODE="enforce"

    _pf="$POLICY_FILE"
    [ -f "$_pf" ] || _pf="/data/adb/shso_guard/policy.conf"
    [ -f "$_pf" ] || _pf="$GUARD_DIR/../policy.conf"
    [ -f "$_pf" ] || return 0
    POLICY_FILE="$_pf"

    while IFS='=' read -r _k _v; do
        case "$_k" in
            \#*) ;;
            protect) _POLICY_PROTECT="$_POLICY_PROTECT $_v" ;;
            allow)   _POLICY_ALLOW="$_POLICY_ALLOW $_v" ;;
            mode)    case "$_v" in enforce|log|off) SHSO_MODE="$_v" ;; esac ;;
        esac
    done < "$_pf"
}

# 判定单个已归一化路径：输出 ALLOW 或 DENY
# 用法: judge <归一化路径>
judge() {
    _path="$1"

    # 1) 豁免优先
    for _a in $_POLICY_ALLOW; do
        [ -z "$_a" ] && continue
        case "$_path" in
            "$_a"|"$_a"/*) echo ALLOW; return 0 ;;
        esac
    done

    # 2) 受保护判定
    for _p in $_POLICY_PROTECT; do
        [ -z "$_p" ] && continue
        if [ "$_p" = "/" ]; then
            # 根路径只做精确匹配，避免 "/*" 误伤所有绝对路径
            [ "$_path" = "/" ] && { echo DENY; return 0; }
            continue
        fi
        case "$_path" in
            "$_p"|"$_p"/*) echo DENY; return 0 ;;
        esac
    done

    echo ALLOW
}

# 审计落盘（追加写；超过上限时保留尾部）
# 用法: audit <verdict> <rule> <cmd> <args> <path>
audit() {
    _vd="$1"; _rule="$2"; _cmd="$3"; _args="$4"; _path="$5"
    _ts=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
    _dir=$(dirname "$AUDIT_LOG" 2>/dev/null)
    [ -n "$_dir" ] && [ ! -d "$_dir" ] && mkdir -p "$_dir" 2>/dev/null

    echo "${_ts}|GUARD|${_vd}|${_rule}|cmd=${_cmd}|args=${_args}|path=${_path}" >> "$AUDIT_LOG" 2>/dev/null

    _n=$(wc -l < "$AUDIT_LOG" 2>/dev/null)
    _n=$(echo "${_n:-0}" | tr -d ' ')
    if [ -n "$_n" ] && [ "$_n" -gt $((AUDIT_MAX_LINES + 400)) ] 2>/dev/null; then
        tail -n "$AUDIT_MAX_LINES" "$AUDIT_LOG" > "$AUDIT_LOG.tmp" 2>/dev/null \
            && mv "$AUDIT_LOG.tmp" "$AUDIT_LOG" 2>/dev/null
    fi
}

# 在 PATH 中查找真实二进制：跳过 guard 目录（防止递归），兜底 /system/bin
# 用法: find_real <cmd>
find_real() {
    _c="$1"
    _OIFS="$IFS"
    IFS=':'
    for _d in $PATH; do
        [ -z "$_d" ] && continue
        case "$_d" in
            "$GUARD_DIR") continue ;;
        esac
        if [ -x "$_d/$_c" ]; then
            IFS="$_OIFS"
            echo "$_d/$_c"
            return 0
        fi
    done
    IFS="$_OIFS"
    echo "/system/bin/$_c"
}
