import os, re

# 路径相对本脚本（位于 shso_guard/ 仓库根），与本机绝对路径解耦。
_HERE = os.path.dirname(os.path.abspath(__file__))
GUARD = os.path.join(_HERE, "guard")
tpl_path = os.path.join(_HERE, "guard-template.sh")
with open(tpl_path, "r", encoding="utf-8") as f:
    tpl = f.read()

# (filename, CMD_NAME, OPERAND_MODE)
specs = [
    ("rm", "rm", "ARGS"),
    ("rmdir", "rmdir", "ARGS"),
    ("shred", "shred", "ARGS"),
    ("truncate", "truncate", "ARGS"),
    ("wipe", "wipe", "ARGS"),
    ("dd", "dd", "DD"),
    ("fastboot", "fastboot", "FASTBOOT"),
    ("mkfs.ext4", "mkfs.ext4", "ARGS"),
    ("mkfs.f2fs", "mkfs.f2fs", "ARGS"),
    ("mkfs.vfat", "mkfs.vfat", "ARGS"),
    ("mke2fs", "mke2fs", "ARGS"),
    ("make_f2fs", "make_f2fs", "ARGS"),
    ("mv", "mv", "MVCP"),
    ("cp", "cp", "MVCP"),
    ("find", "find", "FIND"),
    ("sed", "sed", "SED"),
    # 权限崩坏 / 分区表 / 刷机 类格机原语，均为 ARGS 模式（非选项参数即路径），
    # 命中 protect=/system、/dev、/data 即拦截。
    ("chmod", "chmod", "ARGS"),
    ("chown", "chown", "ARGS"),
    ("chgrp", "chgrp", "ARGS"),
    ("mkfs", "mkfs", "ARGS"),
    ("mknod", "mknod", "ARGS"),
    ("sgdisk", "sgdisk", "ARGS"),
    ("parted", "parted", "ARGS"),
    ("fdisk", "fdisk", "ARGS"),
    ("flash_image", "flash_image", "ARGS"),
    # 不经 dd/rm 的写入原语：ln 可把块设备指向 /dev/null，install 是带属性的 cp，
    # tee 直接把管道内容写进目标文件。
    # 新增项必须同步：guard_operand_mode()、assets/shso_guard.zip、
    # GuardModuleInstaller.REQUIRED_ARCHIVE_ENTRIES，并升 module.prop 版本。
    ("ln", "ln", "MVCP"),
    ("install", "install", "MVCP"),
    ("tee", "tee", "TEE"),
    # 这两个与 guard_operand_mode() 的 ARGS 清单对齐（映射里有、包装器就该有），
    # 否则「toybox wipefs」被拦而直接「wipefs」不拦，形成不对称。
    ("wipefs", "wipefs", "ARGS"),
    ("chattr", "chattr", "ARGS"),
]

others = re.findall(r"__[A-Z_]+__", tpl)
assert set(others) <= {"__CMD_NAME__", "__OPERAND_MODE__"}, others

for fname, cmd, mode in specs:
    out = tpl.replace("__CMD_NAME__", cmd).replace("__OPERAND_MODE__", mode)
    with open(os.path.join(GUARD, fname), "w", encoding="utf-8", newline="\n") as f:
        f.write(out)
    print("wrote", fname)
print("done")
