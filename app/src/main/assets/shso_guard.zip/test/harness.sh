#!/usr/bin/env bash
# Copyright 2026, shso contributors
# SPDX-License-Identifier: GPL-3.0-or-later
# shso_guard 加固后的对抗性冒烟测试（lead 自建，独立于实现者）
#
# 环境注意：本机是 Git Bash on Windows。
#   - 必须使用 POSIX 形式路径（/c/...），否则 PATH 里的盘符冒号会被 IFS=':' 切碎；
#     这是 Windows 测试环境的特性，与 Android 无关（Android 路径无盘符）。
#   - PATH 采用「fakebin 前置 + 保留原 PATH」，否则 sh/tr/date/wc 都找不到。

set -u
# 脚本自带定位：test/ 的父目录即模块目录，避免硬编码仓库绝对路径。
SELF="$(cd "$(dirname "$0")" && pwd)"
ROOT="${ROOT:-$(dirname "$SELF")}"
GUARD="$ROOT/guard"
WORK="$ROOT/.tmp-guard-test/work"
# 桩目录必须落在 MSYS 虚拟文件系统（/tmp）内：仓库位于 NTFS，chmod 755 不生效，
# exec_real 的 [ -x ] 会失败并落到系统真实二进制上，使 ^REAL: 判据失效（Windows 专有陷阱）。
FAKE="${TMPDIR:-/tmp}/shso-harness-fakebin"
ORIG_PATH="$PATH"
EMPTY="$WORK/empty"

rm -rf "$WORK" "$FAKE"; mkdir -p "$FAKE" "$WORK/policy" "$EMPTY"

# 桩列表须覆盖被测命令：新增包装器（ln/install/tee/wipefs/chattr）也要有桩，
# 否则 ALLOW 用例会落到系统真实二进制上，判据（^REAL:）失效。
for c in rm dd find sed mv cp toybox busybox truncate rmdir shred wipe ln install tee wipefs chattr fastboot; do
  printf '#!/bin/sh\necho "REAL:%s $*"\nexit 0\n' "$c" > "$FAKE/$c"
  chmod 755 "$FAKE/$c"
done

PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); printf '  PASS  %s\n' "$1"; }
bad() { FAIL=$((FAIL+1)); printf '  FAIL  %s\n' "$1"; }

# run_case <期望 BLOCK|ALLOW> <描述> <policy> <guard脚本> <参数...>
run_case() {
  local expect="$1" desc="$2" pf="$3" gscript="$4"; shift 4
  local out rc
  out=$(PATH="$FAKE:$ORIG_PATH" SHSO_POLICY="$pf" SHSO_AUDIT="$WORK/audit.log" \
        /bin/sh "$GUARD/$gscript" "$@" 2>&1); rc=$?
  if [ "$expect" = "BLOCK" ]; then
    if [ $rc -ne 0 ] && printf '%s' "$out" | grep -q "已拦截"; then ok "$desc"
    else bad "$desc  期望拦截，实际 rc=$rc out=[$out]"; fi
  else
    if [ $rc -eq 0 ] && printf '%s' "$out" | grep -q "^REAL:"; then ok "$desc -> $(printf '%s' "$out" | head -1)"
    else bad "$desc  期望放行，实际 rc=$rc out=[$out]"; fi
  fi
}

# ---------------------------------------------------------------- 策略文件变体
printf 'mode=enforce\nprotect=/ /system /system_ext /product /vendor /odm /apex /proc /sys /dev /data/system /data/misc /metadata\nallow=/sdcard /storage/emulated /data/media /data/local/tmp\n' > "$WORK/policy/lf.conf"
printf 'mode=enforce\r\nprotect=/ /system /data/system\r\nallow=/sdcard /data/local/tmp\r\n' > "$WORK/policy/crlf.conf"
printf 'mode = enforce\nprotect = /system /data/system\nallow = /sdcard\n' > "$WORK/policy/spaces.conf"
printf '# comment\n\nmode=enforce   # mode\nprotect=/system   # sys\nallow=/sdcard # user\n' > "$WORK/policy/comment.conf"
printf 'mode=garbage\nprotect=/system\nallow=/sdcard\n' > "$WORK/policy/badmode.conf"
printf 'mode=OFF\nprotect=/system\n' > "$WORK/policy/badmode2.conf"
printf 'mode=enforce\nprotect=/system\n' > "$WORK/policy/min.conf"
printf 'mode=enforce\nprotect=/data\nallow=/data/local/tmp\n' > "$WORK/policy/allowfirst.conf"

echo
echo "===== a/b/c/d  策略解析加固（P0 静默 fail-open 修复）====="
run_case BLOCK "a)  CRLF 行尾：rm -rf /system 仍被拦"      "$WORK/policy/crlf.conf"     rm      -rf /system
run_case BLOCK "b)  protect = /system（等号带空格）"        "$WORK/policy/spaces.conf"   rm      -rf /system
run_case BLOCK "c)  行尾内联注释不破坏规则"                 "$WORK/policy/comment.conf"  rm      -rf /system
run_case BLOCK "d)  mode=garbage 回退 enforce 且仍拦截"     "$WORK/policy/badmode.conf"  rm      -rf /system
run_case BLOCK "d2) mode=OFF（大写，非法）回退 enforce"     "$WORK/policy/badmode2.conf" rm      -rf /system
run_case ALLOW "c2) 同一注释策略下 /sdcard 正常放行"        "$WORK/policy/comment.conf"  rm      -rf /sdcard/x
run_case ALLOW "a2) CRLF 策略的 allow 清单同样生效(/sdcard)" "$WORK/policy/crlf.conf"    rm      -rf /sdcard/x
run_case BLOCK "a3) CRLF 策略的 protect 清单同样生效"        "$WORK/policy/crlf.conf"    rm      -rf /data/system/x

echo
echo "===== e/f  toybox / busybox 多二进制绕过（P0）====="
run_case BLOCK "e)   toybox rm -rf /system"                 "$WORK/policy/lf.conf" toybox  rm -rf /system
run_case BLOCK "f)   busybox rm -rf /system"                "$WORK/policy/lf.conf" busybox rm -rf /system
run_case BLOCK "e2)  toybox dd of=/dev/block/sda"           "$WORK/policy/lf.conf" toybox  dd if=/dev/zero of=/dev/block/sda
run_case BLOCK "e3)  toybox wipe（无参）"                   "$WORK/policy/lf.conf" toybox  wipe
run_case ALLOW "e4)  toybox ls（非守卫子命令零干预）"       "$WORK/policy/lf.conf" toybox  ls -l /sdcard

echo
echo "===== g/h/i  新覆盖面 mv / cp / find / sed ====="
run_case BLOCK "g)   mv /system/x /sdcard/（源受保护）"     "$WORK/policy/lf.conf" mv   /system/build.prop /sdcard/
run_case BLOCK "g2)  mv /sdcard/a /system/b（目标受保护）"  "$WORK/policy/lf.conf" mv   /sdcard/a /system/b
run_case BLOCK "g3)  cp /dev/zero /system/build.prop"       "$WORK/policy/lf.conf" cp   /dev/zero /system/build.prop
run_case BLOCK "h)   find /system -delete"                  "$WORK/policy/lf.conf" find /system -name '*.odex' -delete
run_case BLOCK "i)   sed -i 1d /system/build.prop"          "$WORK/policy/lf.conf" sed  -i 1d /system/build.prop
run_case BLOCK "h2)  find /system -exec rm {} ;"            "$WORK/policy/lf.conf" find /system -exec rm {} ";"

echo
echo "===== j/k  既有缺陷（fastboot -w / dd of 带空格 / wipe 无参）====="
run_case BLOCK "j)   fastboot -w"                           "$WORK/policy/lf.conf" fastboot -w
run_case BLOCK "j2)  fastboot flash boot boot.img"          "$WORK/policy/lf.conf" fastboot flash boot boot.img
run_case BLOCK "k)   wipe 无操作数 = 擦默认设备"            "$WORK/policy/min.conf" wipe

echo
echo "===== l  误杀检查（必须全部放行）====="
run_case ALLOW "l1) rm -rf /data/local/tmp/x（豁免）"       "$WORK/policy/lf.conf" rm   -rf /data/local/tmp/x
run_case ALLOW "l2) cp a b（相对路径）"                     "$WORK/policy/lf.conf" cp   a b
run_case ALLOW "l3) find /data/local/tmp -delete"           "$WORK/policy/lf.conf" find /data/local/tmp -delete
run_case ALLOW "l4) sed -i 1d /data/local/tmp/f"            "$WORK/policy/lf.conf" sed  -i 1d /data/local/tmp/f
run_case ALLOW "l5) rm -rf /sdcard/tmp"                     "$WORK/policy/lf.conf" rm   -rf /sdcard/tmp
run_case ALLOW "l6) mv /sdcard/a /sdcard/b"                 "$WORK/policy/lf.conf" mv   /sdcard/a /sdcard/b
run_case ALLOW "l7) find /sdcard -name x（无 -delete）"     "$WORK/policy/lf.conf" find /sdcard -name x
run_case ALLOW "l8) sed s/a/b/ /system/x（无 -i）"          "$WORK/policy/lf.conf" sed  "s/a/b/" /system/x
run_case ALLOW "l9) allow 优先于 protect"                   "$WORK/policy/allowfirst.conf" rm -rf /data/local/tmp/x

echo
echo "===== m  递归守卫 / PATH 写法差异 / 缺失二进制 ====="
out=$(PATH="$GUARD/:/system/bin:$FAKE:$ORIG_PATH" SHSO_POLICY="$WORK/policy/lf.conf" SHSO_AUDIT="$WORK/audit.log" \
      /bin/sh "$GUARD/rm" -rf /sdcard/ok 2>&1); rc=$?
if [ $rc -eq 0 ] && printf '%s' "$out" | grep -q "^REAL:rm"; then ok "m1) PATH 中守卫目录带尾斜杠：不递归"
else bad "m1) 带尾斜杠异常 rc=$rc out=[$out]"; fi

out=$(PATH="$GUARD//./:$FAKE:$ORIG_PATH" SHSO_POLICY="$WORK/policy/lf.conf" SHSO_AUDIT="$WORK/audit.log" \
      /bin/sh "$GUARD/rm" -rf /sdcard/ok 2>&1); rc=$?
if [ $rc -eq 0 ] && printf '%s' "$out" | grep -q "^REAL:rm"; then ok "m2) PATH 中双斜杠点写法：不递归"
else bad "m2) 异常 rc=$rc out=[$out]"; fi

out=$(SHSO_GUARD_DEPTH=9 PATH="$FAKE:$ORIG_PATH" SHSO_POLICY="$WORK/policy/lf.conf" SHSO_AUDIT="$WORK/audit.log" \
      /bin/sh "$GUARD/rm" -rf /sdcard/ok 2>&1); rc=$?
if [ $rc -ne 0 ] && printf '%s' "$out" | grep -q "递归深度超限"; then ok "m3) 深度超限 fail-closed（不挂死）"
else bad "m3) 深度守卫未生效 rc=$rc out=[$out]"; fi

# 缺失真实二进制：PATH 只留不会有 fastboot 的目录（本机 SDK platform-tools 里有 fastboot，必须排除）
out=$(PATH="$EMPTY:/bin" SHSO_POLICY="$WORK/policy/lf.conf" SHSO_AUDIT="$WORK/audit.log" \
      /bin/sh "$GUARD/fastboot" devices 2>&1); rc=$?
if [ $rc -ne 0 ] && printf '%s' "$out" | grep -q "找不到可执行的真实二进制"; then ok "m4) 真实二进制缺失：清晰报错 + fail-closed"
else bad "m4) 缺失二进制处理异常 rc=$rc out=[$out]"; fi

echo
echo "===== s  语法自检（守卫脚本解析失败会让防护全线失效）====="
syn_bad=""
for _f in "$GUARD"/*; do
  case "$_f" in *"/common.sh") continue ;; esac
  /bin/sh -n "$_f" 2>/dev/null || syn_bad="$syn_bad $(basename "$_f")"
done
/bin/sh -n "$GUARD/common.sh" 2>/dev/null || syn_bad="$syn_bad common.sh"
if [ -z "$syn_bad" ]; then ok "s1) 全部守卫脚本语法自检通过"
else bad "s1) 存在语法错误：$syn_bad"; fi

echo
echo "===== v1.3.0 回归用例（派发表 / 新包装器 / 参数变体 / 未解析变量）====="
run_case BLOCK "n1)   toybox chmod -R 777 /system"           "$WORK/policy/lf.conf" toybox chmod -R 777 /system
run_case BLOCK "n2)   toybox chown 0:0 /system"              "$WORK/policy/lf.conf" toybox chown 0:0 /system
run_case BLOCK "n3)   toybox mknod /system/x c 1 3"          "$WORK/policy/lf.conf" toybox mknod /system/x c 1 3
run_case BLOCK "n4)   ln -sf /dev/null /system/x（新包装器）" "$WORK/policy/lf.conf" ln -sf /dev/null /system/x
run_case BLOCK "n5)   toybox ln（派发已补映射）"              "$WORK/policy/lf.conf" toybox ln -sf /dev/null /system/x
run_case BLOCK "n6)   tee /system/x（新包装器）"              "$WORK/policy/lf.conf" tee /system/x
run_case BLOCK "n7)   wipefs -a /system/x（新包装器）"        "$WORK/policy/lf.conf" wipefs -a /system/x
run_case BLOCK "n8)   find -exec /system/bin/rm（basename 判定）" "$WORK/policy/lf.conf" find /system -maxdepth 1 -exec /system/bin/rm -rf '{}' ";"
run_case BLOCK "n9)   sed --in-place（长选项）"               "$WORK/policy/lf.conf" sed --in-place 1d /system/build.prop
run_case BLOCK "n10)  rm -rf \$X（未解析变量 fail-closed）"   "$WORK/policy/lf.conf" rm -rf '$X'
run_case ALLOW "n11)  ln -sf /sdcard/a /data/local/tmp/b（豁免）" "$WORK/policy/lf.conf" ln -sf /sdcard/a /data/local/tmp/b
run_case ALLOW "n12)  tee /data/local/tmp/x（豁免）"          "$WORK/policy/lf.conf" tee /data/local/tmp/x

# `-t <dir>` 语义是「把所有源搬进 dir」，末操作数是**源**而非目标。
# 只判末位会让 `cp -t /system/bin a b` 整条放行（真机实测：toybox cp 报 Unknown option t
# 后放行，App 侧静态层也只取末操作数），故守卫必须显式识别 -t 的取值。
run_case BLOCK "n15)  cp -t /system/bin（目标目录形态）"     "$WORK/policy/lf.conf" cp -t /system/bin /sdcard/a /sdcard/b
run_case BLOCK "n16)  mv -t /system/bin（目标目录形态）"     "$WORK/policy/lf.conf" mv -t /system/bin /sdcard/a
run_case BLOCK "n17)  cp --target-directory=/system/bin"    "$WORK/policy/lf.conf" cp --target-directory=/system/bin /sdcard/a
run_case ALLOW "n18)  cp -t /data/local/tmp（豁免目标）"   "$WORK/policy/lf.conf" cp -t /data/local/tmp /sdcard/a
# 必选参数可与短选项紧贴：GNU getopt_long 与 busybox getopt32 都接受 `-tDIR`。
# 旧实现只认 `-t DIR`，于是 `cp -t/system/bin a` 既漏判目标、又把末位源当目标，整条放行。
run_case BLOCK "n19)  cp -t/system/bin（紧贴取值）"       "$WORK/policy/lf.conf" cp -t/system/bin /sdcard/a
run_case BLOCK "n20)  mv -t/system/bin（紧贴取值）"       "$WORK/policy/lf.conf" mv -t/system/bin /sdcard/a
run_case ALLOW "n21)  cp -t/data/local/tmp（紧贴豁免）"   "$WORK/policy/lf.conf" cp -t/data/local/tmp /sdcard/a

# `find` 起始路径提取：旧实现「取第一个非选项参数就 break」，
# 被前置选项（-name/-type/-maxdepth…）骗过——把选项值当唯一路径判掉，真正的受保护路径从未入判。
run_case BLOCK "o1)   find -name x /system -delete（前置选项）"   "$WORK/policy/lf.conf" find -name x /system -delete
run_case BLOCK "o2)   find -type f /system -delete（前置选项）"   "$WORK/policy/lf.conf" find -type f /system -delete
run_case BLOCK "o3)   find -maxdepth 1 /system -delete（前置选项）" "$WORK/policy/lf.conf" find -maxdepth 1 /system -delete
run_case BLOCK "o4)   find /sdcard -name x /system -delete（双路径）" "$WORK/policy/lf.conf" find /sdcard -name x /system -delete
# -exec 名单必须与顶层 ARGS 对齐：顶层已拦的原语从 -exec 漏掉即等于没拦。
run_case BLOCK "o5)   find -exec truncate"       "$WORK/policy/lf.conf" find /system -maxdepth 1 -exec truncate -s 0 '{}' ";"
run_case BLOCK "o6)   find -exec dd"             "$WORK/policy/lf.conf" find /system -maxdepth 1 -exec dd of=/dev/null '{}' ";"
run_case BLOCK "o7)   find -exec cp"             "$WORK/policy/lf.conf" find /system -maxdepth 1 -exec cp '{}' /sdcard/x ";"
run_case BLOCK "o8)   find -exec sed -i"         "$WORK/policy/lf.conf" find /system -maxdepth 1 -exec sed -i s/a/b/ '{}' ";"
run_case BLOCK "o9)   find -exec wipefs"         "$WORK/policy/lf.conf" find /system -maxdepth 1 -exec wipefs -a '{}' ";"
run_case BLOCK "o10)  find -exec chmod"         "$WORK/policy/lf.conf" find /system -maxdepth 1 -exec chmod 777 '{}' ";"
run_case ALLOW "o11)  find -name x /data/local/tmp -delete（豁免）" "$WORK/policy/lf.conf" find -name x /data/local/tmp -delete
# sed 短选项捆绑：POSIX 允许 `-ni` 把多个标志写成一个 token，同一效果换个写法即绕过。
run_case BLOCK "p1)   sed -ni（短选项捆绑）"     "$WORK/policy/lf.conf" sed -ni 1d /system/build.prop
run_case BLOCK "p2)   sed -in（短选项捆绑）"     "$WORK/policy/lf.conf" sed -in 1d /system/build.prop
run_case ALLOW "p3)   sed -n 1d（无 -i 不介入）" "$WORK/policy/lf.conf" sed -n 1d /system/build.prop
# fastboot：`flash` 整参数精确匹配漏掉 `flashall`（整盘重刷）与 `flashing`（unlock 前置）；
# `"oem unlock"` 写在 case 里永不命中，因为 "$@" 已按空白拆成两个参数。
run_case BLOCK "q1)   fastboot flashall"        "$WORK/policy/lf.conf" fastboot flashall
run_case BLOCK "q2)   fastboot flashing lock"   "$WORK/policy/lf.conf" fastboot flashing lock
run_case BLOCK "q3)   fastboot oem unlock"      "$WORK/policy/lf.conf" fastboot oem unlock
run_case BLOCK "q4)   fastboot flash boot"      "$WORK/policy/lf.conf" fastboot flash boot
run_case ALLOW "q5)   fastboot devices（只读）" "$WORK/policy/lf.conf" fastboot devices

echo
echo "===== 环境变量越权（SHSO_POLICY 指向可写路径的 mode=off，必须被忽略）====="
printf 'mode=off\n' > "$WORK/policy/evil.conf"
out=$(PATH="$FAKE:$ORIG_PATH" SHSO_POLICY="$WORK/policy/evil.conf" SHSO_AUDIT="$WORK/audit.log" \
      /bin/sh "$GUARD/rm" -rf /system 2>&1); rc=$?
if [ $rc -ne 0 ] && printf '%s' "$out" | grep -q "已拦截"; then ok "n13) 越权 SHSO_POLICY 被忽略，仍按默认策略拦截"
else bad "n13) 越权生效（未拦截）rc=$rc out=[$out]"; fi

echo
echo "===== 审计留痕与字段清洗 ====="
# 注意：SHSO_AUDIT 现只接受 /data/adb/shso/ 前缀，Git Bash 下必然被忽略，
# 因此这里直接 source 后覆盖 AUDIT_LOG（不经环境变量），否则断言会假失败。
rm -f "$WORK/audit.log"
(
  . "$GUARD/common.sh"
  AUDIT_LOG="$WORK/audit.log"
  audit DENY PROTECTED_PATH rm "-rf /system" "/system"
  audit ALLOW NONE rm "-rf /x
2026-01-01 00:00:00|GUARD|ALLOW|NONE|cmd=rm|args=-rf /|path=/" "/x"
)
if [ -s "$WORK/audit.log" ] && grep -q "GUARD" "$WORK/audit.log"; then
  ok "审计日志已写入（含 GUARD 前缀 / $(grep -c . "$WORK/audit.log") 行）"
  echo "        尾行: $(tail -1 "$WORK/audit.log")"
else bad "审计日志未写入"; fi
if grep -q "DENY" "$WORK/audit.log" && grep -q "ALLOW" "$WORK/audit.log"; then ok "DENY 与 ALLOW 均已留痕"; else bad "审计未同时记录 DENY/ALLOW"; fi
if [ "$(grep -c '^2026-01-01' "$WORK/audit.log" 2>/dev/null)" = "0" ]; then ok "n14) 审计字段清洗：无伪造行"
else bad "n14) 审计字段清洗失败（出现伪造整行）"; fi

echo
echo "===== 汇总 ====="
printf 'PASS=%d  FAIL=%d\n' "$PASS" "$FAIL"
[ "$FAIL" -eq 0 ] && echo "全部通过" || echo "存在失败"
exit $([ "$FAIL" -eq 0 ] && echo 0 || echo 1)
